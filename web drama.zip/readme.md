# DramaBox Website

Website untuk menonton drama gratis menggunakan API DramaBox.

## Fitur

1. **Beranda Lengkap** dengan 5 seksi:
   - Rekomendasi Untukmu
   - Drama Trending
   - Drama Terbaru
   - Drama VIP
   - Pencarian Populer

2. **Pencarian** real-time dengan saran pencarian

3. **Detail Drama** lengkap dengan:
   - Sinopsis
   - Genre/Tag
   - Daftar episode
   - Informasi pemain

4. **Pemutar Video** dengan:
   - Multi-kualitas (144p, 360p, 540p, 720p, 1080p)
   - Kontrol play/pause, volume, fullscreen
   - Auto-play episode berikutnya
   - Pilihan kualitas video

5. **Fitur Pengguna**:
   - Riwayat tontonan
   - Daftar favorit
   - Pencarian terbaru

## Struktur File
